#include<iostream>
#include<string>

using std::cout;
using std::string;

class display{
	public:
		void side(bool d=true){cout<<"|";}
		void top_bot(bool d=true){
			cout<<"\n+---------------------------";
			cout<<"-----------------------------+\n";
		}
		void cen_mess(string mess,float width=56){
			int m_len=mess.length();
			int rem=m_len%2;
			string gap=string((width-mess.length())/2,' ');
			if(rem==0){
				mess=gap+mess+gap;
				cout<<mess;}
			else{
				mess=gap+mess+gap+' ';
				cout<<mess;
			}
		}
		void message(string mess,bool l,bool r,bool t,bool b){
			if(t==true){top_bot(t);}
			if(l==true){side(l);}
			cen_mess(mess);
			if(r==true){side(r);}
			if(b==true){top_bot(b);}
		}
};

