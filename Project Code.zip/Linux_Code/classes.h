#include<iostream>
#include<string>
using namespace std;

class name{
	private:
		string f_name,m_name,l_name;
	public:
		name(){ f_name="\0";m_name="\0";l_name="\0"; }
		name(string f,string m,string l){ f_name=f;m_name=m;l_name=l; }

		void set_f_name(string f){ f_name=f; }
		void set_m_name(string m){ m_name=m; }
		void set_l_name(string l){ l_name=l; }

		string get_f_name(){ return f_name; }
		string get_m_name(){ return m_name; }
		string get_l_name(){ return l_name; }

		void input_name(){
			cout<<"\nFirst Name:";
			string f;
			cin>>f;
			set_f_name(f);
			cout<<"Middel Name:";
			string m;
			cin>>m;
			set_m_name(m);
			cout<<"Last Name:";
			string l;
			cin>>l;
			set_l_name(l);
		}

		void print_name(){ cout<<f_name<<" "<<m_name<<" "<<l_name; }
		string get_full_name(){ return (f_name+" "+m_name+" "+l_name); }

};


class address{
	private:
		string house,street,sector,city;
	public:
		address(){ house="\0";street="\0";sector="\0";city="\0"; }
		address(string h,string st,string se,string c){ house=h;street=st;sector=se;city=c; }

		void set_house(string h){ house=h; }
		void set_street(string s){ street=s; }
		void set_sector(string se){ sector=se; }
		void set_city(string c){ city=c; }

		string get_house(){ return house; }
		string get_street(){ return street; }
		string get_sector(){ return sector; }
		string get_city(){ return city; }

		void input_address(){
			cout<<"\nEnter Building\\House Number: ";
			string h;
			cin>>h;
			set_house(h);
			cout<<"Enter Street Number: ";
			string st;
			cin>>st;
			set_street(st);
			cout<<"Enter Sector Number: ";
			string s;
			cin>>s;
			set_sector(s);
			cout<<"Enter City: ";
			string c;
			cin>>c;
			set_city(c);
		}

		void print_address(){
			cout<<"house:"<<house<<",street:"<<street;
			cout<<",sector:"<<sector<<",city:"<<city<<endl;
		}

		string get_full_address(){ return (house+" "+street+" "+sector+" "+city); }

};


class date{
	private:
		string day,month,year;
		public:
		date(){day="\0";month="\0";year="\0";}
		date(string d,string m,string y){day=d;month=m;year=y;}

		void set_day(string d){day=d;}
		void set_month(string m){month=m;}
		void set_year(string y){year=y;}

		string get_day(){return day;}
		string get_month(){return month;}
		string get_year(){return year;}

		void input_date(){
			cout<<"\nDay:";
			string d;
			cin>>d;
			set_day(d);
			cout<<"Month:";
			string m;
			cin>>m;
			set_month(m);
			cout<<"Year:";
			string y;
			cin>>y;
			set_year(y);
		}

		void print_date(){ cout<<day<<"/"<<month<<"/"<<year; }
		string get_full_date(){ return (day+" "+month+" "+year); }
};//date class


class branch{
	private:
		string b_id;
		string branch_name;
		string postal_code;
		string branch_contact;
		address b_add;
	public:
		branch(){
			b_id="\0"; branch_name= "\0"; postal_code= "\0"; branch_contact= "\0"; b_add= {};
		}
		string get_id(){ return b_id; }

		void input_branch(){
			cout<<"\nBranch id:";
			cin>>b_id;
			cout<<"\nBranch Name:";
			cin>>branch_name;
			cout<<"\nPostal Code:";
			cin>>postal_code;
			cout<<"\nBranch Contact Number:";
			cin>>branch_contact;
			cout<<"\nEnter the Branch Address:";
			b_add.input_address();
		}

		void set_branch (string id, string name, string code, string contact, string house, string street, string sector, string city){
            b_id=id; branch_name=name; branch_contact=contact; postal_code=code;
            b_add.set_house(house); b_add.set_street(street); b_add.set_sector(sector); b_add.set_city(city);
		}

		void print_branch(){
			cout<<"\nBranch Id:"<<b_id;
			cout<<"\nBranch Address:";
			b_add.print_address();
		}

		string get_file_string(){
			return (b_id+"\n"+branch_name+"\n"+postal_code+"\n"+branch_contact+"\n"+b_add.get_full_address());
		}

};//branch class



class person{
	private:
		name name_per;
		string contact_no;
		address address_per;

	public:
		person(){name_per={};contact_no={};address_per={};}

		person(string fn, string mn, string ln, string cont, string hou, string str, string sec, string city ) : name_per(fn, mn, ln ), contact_no(cont), address_per(hou, str, sec, city ) {}

		void set_person(string fn, string mn, string ln, string cont, string hou, string str, string sec, string city ){
			name_per.set_f_name(fn); name_per.set_m_name(mn); name_per.set_l_name(ln);
			contact_no= cont;
			address_per.set_house(hou); address_per.set_street(str); address_per.set_sector(sec); address_per.set_city(city);
		}

		void input_person(){
			cout<<"Enter Name:"<<endl;
			name_per.input_name();
			cout<<"Enter Contact Number:";
			cin>>contact_no;
			cout<<"Enter Address:"<<endl;
			address_per.input_address();
		}

		void print_person(){
			cout<<"\nName:";
			name_per.print_name();
			cout<<"\nContact Number:";
			cout<<contact_no;
			cout<<"\nAddress:";
			address_per.print_address();
		}

		string get_full_name(){ return name_per.get_full_name(); }
		string get_contact(){ return contact_no; }
		string get_full_address(){ return address_per.get_full_address(); }
};


class parcel{
	private:
		string id;
		person sender;
		person recipient;
		string fragile;
		float weight,hieght,length,width,price;

	public:
		parcel(){ id= "\0"; sender={}; recipient={}; fragile=false; weight=hieght=length=width=price={}; }

		parcel( string p_id, string sfn, string smn, string sln, string scont, string shou, string sstr, string ssec, string scity,string rfn, string rmn, string rln, string rcont, string rhou, string rstr, string rsec, string rcity, string frag, float wei, float hie, float len, float wid, float pri ) : sender(sfn, smn, sln, scont, shou, sstr, ssec, scity) , recipient(rfn, rmn, rln, rcont, rhou, rstr, rsec, rcity) , fragile(frag) {

			id= p_id; weight=wei; hieght=hie; length=len; width=wid; price= pri;
		}

		void set_parcel(const string p_id, const person & sn, const person & rc, const string frag, const float wei, const float hie, const float len, const float wid, const float pri){
			sender= sn; recipient= rc; fragile= frag;
			id= p_id; weight= wei; hieght= hie; length= len; width= wid; price= pri;
		}

		void parcel_details(){
			cout<<"\nWeight:";
			cin>>weight;
			cout<<"Hieght:";
			cin>>hieght;
			cout<<"Length:";
			cin>>length;
			cout<<"Width:";
			cin>>width;
			cout<<"Price:";
			cin>>price;
			bool f;
			cout<<"Is Parcel Fragile(true(1),false(0)):";
			cin>>f;
			fragile=check_fragility(f);
		}

		//void branch_select(){}
		string check_fragility(bool fr){
			if(fr==true){
				return "Fragile";
			}

			return "Non_Fragile";
		}

		void input_parcel(){
			cout<<"Parcel ID: ";
			cin >> id;
			cout<<"_Sender_\n";
			sender.input_person();
			cout<<"Recipient\n";
			recipient.input_person();
			parcel_details();

		}

		void print_parcel(){
			cout<<"Parcel ID: "<<id<<endl;
			cout<<"Sender\n";
			sender.print_person();
			cout<<"Recipient\n";
			recipient.print_person();
			cout<<"\n Weight:"<<weight;
			cout<<"\n Hieght:"<<hieght;
			cout<<"\n Lenght:"<<length;
			cout<<"\n Width:"<<width;
			cout<<"\n price:"<<price;
			cout<<"\n "<<fragile;
			cout<<"\n";

		}

		string get_id(){ return id; }

		string get_file_string(){
			return (id+"\n"+sender.get_full_name()+"\n"+sender.get_full_address()+"\n"+
                        sender.get_contact()+"\n"+recipient.get_full_name()+"\n"+
                        recipient.get_full_address()+"\n"+recipient.get_contact()+"\n"+
                        to_string(weight)+"\n"+to_string(hieght)+"\n"+to_string(length)+"\n"+to_string(width)+"\n"+to_string(price)+"\n"+fragile);
		}
};//parcel class

class employee{
	private:
		string e_id;
		name e_name;
		address e_add;
		date birth;
		date join;
		string job;
	public:
		employee(){
			e_id = "\0"; e_name= {}; e_add = {};
			birth= {}; join= {}; job= "\0";
		}

		employee ( const string id, const string fn, const string mn, const string ln, const string ho, const string str, const string sec, const string city, const string bd, const string bm, const string by, const string jd, const string jm, const string jy , const string e_job) : e_id(id), e_name(fn,mn,ln), e_add(ho, str, sec, city), birth(bd, bm, by), join(jd, jm, jy), job(e_job) {}

		void set_employee ( const string & id, const name & e_n, const address & add, const date & e_birth, const date & e_join, string e_job){
			e_id= id; e_name= e_n; e_add= add; birth= e_birth; join= e_join; job= e_job;
		}

		string get_id(){ return e_id; }

		void jobs_list(){
			cout<<"1)Admisterator\n";
			cout<<"2)Delivery\n";
			cout<<"3)Manager\n";
			cout<<"4)Human Resource\n";
			cout<<"5)Cheff//Cook//\n";
			cout<<"6)Cleaner";
			int c;
			cout<<"\n Choose:";
			cin>>c;
			cout<<" \n";
			job_select(c);
		}

		string job_select(int c){
			switch(c){
				case 1:
					job="Administerator";
					break;
				case 2:
					job="Deliverer";
					break;
				case 3:
					job="Manager";
					break;
				case 4:
					job="Human_Resource";
					break;
				case 5:
					job="5)Cheff_or_Cook";
					break;
				case 6:
					job="6)Cleaner";
					break;
			}
			return job;
		}

		void input_employee(){
			cout<<"Enter Employee Id:";
			cin>>e_id;
			cout<<"Enter Employee name:";
			e_name.input_name();
			cout<<"Enter Employee Address: ";
			e_add.input_address();

			cout<<"Enter Employee Date of Birth:";
			birth.input_date();
			cout<<"Enter the Date of Joining:";
			join.input_date();
			cout<<"Enter Employees Job:\n";
			jobs_list();
		}

		string get_job(){return job;}

		void print_employee(){
			cout<<"\n Employee id:"<<e_id;
			cout<<"\n Employee Name:";
			e_name.print_name();
			cout<<"\n Employee Address:";
			e_add.print_address();
			cout<<"\n Employee Date of Birth:";
			birth.print_date();
			cout<<"\n Employee Date of Joining:";
			join.print_date();
			cout<<"\n Employee Job:"<<job;
		}

		string get_file_string(){
			return ( e_id +"\n"+e_name.get_full_name()+"\n"+e_add.get_full_address()+"\n"+birth.get_full_date()+"\n"+join.get_full_date()+"\n"+job );
		}

};

