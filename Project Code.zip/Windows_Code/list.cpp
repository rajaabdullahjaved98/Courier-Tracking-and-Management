#include <fstream>
#include <iostream>
#include "classes.h"
#include "display.h"
using namespace std;

struct node_parcel{
	parcel p;
	node_parcel *p_next;
};
class parcel_stack{
	node_parcel *top;
	node_parcel *bot;
	int stack_size;
	public:
	parcel_stack(){
		top=NULL;
		bot=NULL;
		stack_size=0;
	}
	void push(const parcel & push_parcel){
		node_parcel *add= new node_parcel;
		add->p= push_parcel;
		if (top==NULL){
			top=add;
			bot=add;
			top->p_next=NULL;
		}else{
			add->p_next=top;
			top=add;
		}
		stack_size++;
	}

	parcel pop(){
		if(top!=NULL){
			node_parcel *temp= top;
			top=top->p_next;
			parcel ret=temp->p;
			delete temp;
			stack_size--;
			return ret;
		}
		else{
			return {};
		}
	}

	int size(){
		return stack_size;
	}

	bool empty(){
		return (stack_size==0);
	}

	~parcel_stack()
	{
		while(stack_size>0)
		{
			pop();
		}
	}
};

class parcel_list{
	node_parcel *front;
	node_parcel *rear;
	int list_size;
	public:
	parcel_list(){
		front = NULL;
		rear =NULL;
		list_size = 0;
	}
	void insert_parcel(){
		node_parcel *temp=new node_parcel;
		temp->p.input_parcel();
		temp->p_next=NULL;
		if(front==NULL){
			front=temp;
			rear=temp;
			front->p_next= NULL;
		}else{
			rear->p_next= temp;
			rear= temp;
			rear->p_next= NULL;
		}
		list_size++;
	}

	void insert_parcel(const parcel & ins){
		node_parcel *temp=new node_parcel;
		temp->p = ins;
		temp->p_next=NULL;
		if(front==NULL){
			front=temp;
			rear=temp;
		}else{
			rear->p_next= temp;
			rear= temp;
			rear->p_next= NULL;
		}
		list_size++;
	}

	void search_parcel(const string & id){
		node_parcel *temp;
		if (!empty()){
			if ((rear->p).get_id() == id){
				cout << "The parcel with id ("<<id<<") is:" <<endl;
				rear->p.print_parcel();
				return;
			}

			temp= front;
			while (temp->p.get_id() != id && temp->p_next != NULL){
				temp = temp->p_next;
			}

			if(temp==rear){
				cout<<"Parcel with id ("<<id<<") not found"<<endl;
				return;
			}

			cout << "The parcel with id ("<<id<<") is:" <<endl;
			temp->p.print_parcel();
			return;
		}
	}

	bool empty(){return (front==NULL);}
	int get_size(){return list_size; }

	parcel queue_front (){
		return front->p;
	}

	void delete_parcel(){
		node_parcel *temp= front;
		if(temp==NULL){
			return;
		}else{
			front = front->p_next;
			temp->p_next=NULL;
			delete temp;
			list_size--;
		}
	}

	void print_que(){

		node_parcel *temp=front;
		while(temp!=NULL){
			(temp->p).print_parcel();
			temp=temp->p_next;
		}
	}

};

struct node_emp{
	employee e;
	node_emp *next;
};

class employee_list{
	node_emp *top;
	node_emp *bot;
	int emp_count;
	public:
	employee_list(){
		top= NULL;
		bot= NULL;
		emp_count =0;
	}

	void insert_employee(){
		node_emp *temp=new node_emp;
		temp->e.input_employee();
		temp->next=top;
		if(top==NULL){
			top=temp;
			bot=temp;
			temp->next=NULL;
		}else{
			top=temp;
		}
		emp_count++;
	}

	void insert_employee(const employee & ins){
		node_emp *temp=new node_emp;
		temp->e= ins;
		temp->next=top;
		if(top==NULL){
			top=temp;
			bot=temp;
			temp->next=NULL;
		}else{
			top=temp;
		}
		emp_count++;
	}

	bool empty(){ return emp_count==0; }
	int get_size(){return emp_count;}

	employee top_emp (){ return top->e; }

	void search_employee(const string & id){
		node_emp *temp;
		if (!empty()){
			if ((bot->e).get_id() == id){
				cout << "The employee with id ("<<id<<") is:" <<endl;
				bot->e.print_employee();
				return;
			}

			temp= top;
			while (temp->e.get_id() != id && temp->next != NULL){
				temp = temp->next;
			}

			if(temp==bot){
				cout<<"Employee with id ("<<id<<") not found"<<endl;
				return;
			}

			cout << "The employee with id ("<<id<<") is:" <<endl;
			temp->e.print_employee();
			return;
		}
	}

	void delete_emp(){
		node_emp *temp= top;
		if (top == NULL){
			return;
		}

		top= top->next;
		temp->next =NULL;

		delete temp;
		emp_count--;
	}

	void display_employee(){
		node_emp *temp=top;
		while(temp != NULL)
		{
			temp->e.print_employee();
			temp = temp->next;
		}
	}

};
struct node_branch{
	node_branch *pre;
	branch b;
	node_branch *next;
};
class branch_linked_list{
	node_branch *top;
	node_branch *bot;
	int branch_count;

	public:
	branch_linked_list(){
		top = NULL;
		bot = NULL;
		branch_count = 0;
	}

	void insert_branch(){
		node_branch *temp=new node_branch;
		(temp->b).input_branch();
		temp->next=top;
		if(top==NULL){
			top=temp;
			bot=temp;
			bot->next=NULL;
			temp=NULL;
		}
		else{
			top=temp;
		}
		branch_count++;
	}

	void insert_branch(const branch & ins_br){
		node_branch *temp = new node_branch;
		temp->b = ins_br;
		temp->next = top;
		if(top==NULL){
			top=temp;
			bot=temp;
			bot->next=NULL;
			temp=NULL;
		}
		else{
			top=temp;
		}
		branch_count++;
	}

	int get_branch_count(){return branch_count;}

	bool empty() { return branch_count == 0; }

	branch list_top (){	return top->b; }

	void delete_branch(){
		node_branch *temp;
		temp=top;
		top=top->next;
		temp->next=NULL;
		branch_count--;
		delete temp;
	}

	void search_branch(const string & id){
		node_branch *temp;
		if (!empty()){
			if ((bot->b).get_id() == id){
				cout << "The branch with id ("<<id<<") is:" <<endl;
				bot->b.print_branch();
				return;
			}

			temp= top;
			while (temp->b.get_id() != id && temp->next != NULL){
				temp = temp->next;
			}

			if(temp==bot){
				cout<<"Branch with id ("<<id<<") not found"<<endl;
				return;
			}

			cout << "The branch with id ("<<id<<") is:" <<endl;
			temp->b.print_branch();
			return;
		}
	}

	void delete_pos(int pos){
		node_branch *pre;
		node_branch *cur=top;
		for(int i=1;i<=pos;i++){
			pre=cur;
			cur=cur->next;
		}
		delete pre->next;
	}

	void print_branch(){
		node_branch *temp=top;
		while(temp != NULL)
		{
			(temp->b).print_branch();
			temp = temp->next;
		}
	}
};

void employee_select(int ch){
	employee_list emp;
	ifstream inf("Employee.txt");
	if (inf.is_open()){
		employee ins;
		string e_id;
		string e_fn, e_mn, e_ln;
		string e_ho, e_str, e_sec, e_city;
		string e_bd, e_bm, e_by;
		string e_jd, e_jm, e_jy;
		string e_job, semi_colon;

		while (inf >> e_id >> e_fn >> e_mn >> e_ln >> e_ho >> e_str >> e_sec >> e_city >>
				e_bd >> e_bm >> e_by >> e_jd >> e_jm >> e_jy >> e_job >> semi_colon){
			ins.set_employee (e_id, name(e_fn,e_mn,e_ln), address(e_ho, e_str, e_sec, e_city), date(e_bd, e_bm, e_by), date(e_jd, e_jm, e_jy), e_job);
			emp.insert_employee(ins);
		}

		inf.close();
	}

	switch(ch){
		case 1:
			emp.insert_employee();
			break;
		case 2:
			if (!emp.empty()){
				emp.delete_emp();
				cout << "Employee deleted successfully." << endl;
				cout << "Updated Employee data:" << endl;
				emp.display_employee();
			}
			break;
		case 3:
			{
				string id;
				cout<<"Enter the id of the employee to search: ";
				cin>> id;
				emp.search_employee(id);
			}
			break;
		case 4:
			if (!emp.empty()){
				emp.display_employee();
			}
			break;
		default:
			return;
	}

	ofstream ouf("Employee.txt",ios::trunc);
	if(ouf.is_open()){
		while (!emp.empty()) {
			ouf << (emp.top_emp()).get_file_string() << endl;
			ouf << ";";

			if (!(emp.get_size()==1)){
				ouf<<endl;
			}
			emp.delete_emp();
		}

		ouf.close();
	}
}

void branch_select(int ch){

	branch_linked_list b;
	ifstream inf("Branch.txt");
	if(inf.is_open())
	{
		branch ins;
		string b_id, branch_name, postal_code, branch_contact, house, street, sector, city, semi_colon;
		while (inf >> b_id >> branch_name >> postal_code >> branch_contact >> house >> street >> sector >> city >> semi_colon){
			ins.set_branch(b_id,branch_name,postal_code,branch_contact,house,street,sector,city);
			b.insert_branch(ins);
		}
		inf.close();
	}
	switch(ch){
		case 1:
			b.insert_branch();
			break;
		case 2:
			if (b.get_branch_count()>0){
				b.delete_branch();
				cout << "Branch deleted successfully." << endl;
				cout << "Updated branch data:" << endl;
				b.print_branch();
			}
			break;
		case 3:
			{
				string id;
				cout<<"Enter the id of the branch to search: ";
				cin>> id;
				b.search_branch(id);
			}
			break;
		case 4:
			b.print_branch();
			break;
		default:
			return;
	}
	ofstream ouf("Branch.txt",ios::trunc);
	if(ouf.is_open()){
		while (b.get_branch_count()> 0) {
			ouf << (b.list_top()).get_file_string() << endl;
			ouf << ";";

			if (!(b.get_branch_count()==1)){
				ouf<<endl;
			}
			b.delete_branch();
		}

		ouf.close();
	}
}
void parcel_select(int ch){
	parcel_list par;
	parcel_stack st;
	ifstream inf("Parcel.txt");
	if(inf.is_open())
	{
		parcel ins;
		string id;
		person sender, recipient;
		string sfn, smn, sln, sha, ssa, ssec_a, scity, scon;
		string rfn, rmn, rln, rha, rsa, rsec_a, rcity, rcon;
		float wei=0.0,hie=0.0,len=0.0,wid=0.0,pri=0.0;
		string frag;
		string semi_colon;

		while (inf >> id >> sfn >> smn >> sln >> sha >> ssa >> ssec_a >> scity >> scon
				>> rfn >> rmn >> rln >> rha >> rsa >> rsec_a >> rcity >> rcon
				>> wei >> hie >> len >> wid >> pri >> frag >> semi_colon){
			sender.set_person(sfn,smn,sln,scon,sha,ssa,ssec_a,scity);
			recipient.set_person(rfn,rmn,rln,rcon,rha,rsa,rsec_a,rcity);
			ins.set_parcel(id, sender, recipient, frag, wei, hie, len, wid, pri);
			st.push(ins);
		}
		inf.close();
		while (!st.empty()){
			par.insert_parcel(st.pop());
		}
	}
	switch(ch){
		case 1:
			par.insert_parcel();
			break;
		case 2:
			if (!par.empty()){
				par.delete_parcel();
				cout << "Parcel deleted successfully." << endl;
				cout << "Updated parcels data:" << endl;
				par.print_que();
			}
			break;
		case 3:
			{
				string id;
				cout<<"Enter the id of the parcel to search: ";
				cin>> id;
				par.search_parcel(id);
			}
			break;
		case 4:
			par.print_que();
			break;
		default:
			return;
	}

	ofstream ouf("Parcel.txt",ios::trunc);
	if(ouf.is_open()){
		while (!par.empty()){
			ouf << ((par.queue_front()).get_file_string()) << endl;
			if (par.get_size() > 1){
				ouf << ";\n";
				par.delete_parcel();
				continue;
			}
			ouf << ";";
			par.delete_parcel();
		}
		ouf.close();
	}

}

void branch_menue(bool tf){
	display d;
	int c;
	d.message("1)Add New Branch",1,1,1,0);
	d.message("2)Delete Top Branch",1,1,1,0);
	d.message("3)Search a Branch",1,1,1,1);
	d.message("4)Branch List",1,1,0,1);
	d.message("5)Back",1,1,0,1);
	cout<<"\n Choose:";
	cin>>c;
	branch_select(c);
}

void employee_menue(bool tf){
	display d;
	int c;
	d.message("1)Add New Employee",1,1,1,0);
	d.message("2)Delete Top Employee",1,1,1,0);
	d.message("3)Search an Employee",1,1,1,1);
	d.message("4)Employee List",1,1,0,1);
	d.message("5)Back",1,1,0,1);
	cout<<"\n Choose:";
	cin>>c;
	employee_select(c);
}

void parcel_menue(bool tf){
	display d;
	int c;
	d.message("1)Add New Parcel",1,1,1,0);
	d.message("2)Delete Top Parcel",1,1,1,0);
	d.message("3)Search a Parcel",1,1,1,1);
	d.message("4)Parcel List",1,1,0,1);
	d.message("5)Back",1,1,0,1);
	cout<<"\n Choose:";
	cin>>c;
	parcel_select(c);
}

void main_select(int ch){
	switch(ch){
		case 1:
			system("CLS");
			branch_menue(true);
			break;
		case 2:
			system("CLS");
			employee_menue(true);
			break;
		case 3:
			system("CLS");
			parcel_menue(true);
			break;
	}
}

int admin_menue(){
	display d;
	int c;
	d.message("1)Branch",1,1,1,1);
	d.message("2)Employee",1,1,0,1);
	d.message("3)Parcel",1,1,0,1);
	d.message("4)Exit",1,1,0,1);
	cout<<"\nChoose:";
	cin>>c;
	if (c!=4){
		main_select(c);
		return 0;
	}
	return -1;
}

int main(){
	while (admin_menue() != -1);
}
